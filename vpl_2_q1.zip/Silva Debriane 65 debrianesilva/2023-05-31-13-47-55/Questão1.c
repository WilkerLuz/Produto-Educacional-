#include<stdio.h>
int main(){
    int a,mut;
    printf("Os cinco primeiros múltiplos de 5 são");
    scanf("%d %d ",&a,&mut);
    for(a=5;mut<=25;++a){
        mut+=a;
    }
      
  
    return 0;
}