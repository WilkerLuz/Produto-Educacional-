#include <stdio.h>
int main(){
    int multi = 0,i, cont = 0;
    i = 5;

printf("Os cinco primeiros múltiplos de 5 são: ");
    while (cont < 5){
        printf(" %i", i);
     i = i+5;
     cont++;
    }
    
    
    
    return 0;
}