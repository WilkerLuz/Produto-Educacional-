#include <stdio.h>

int main(){
    
int n=5,cont=1;

printf(" Os cinco primeiros múltiplos de 5 são: ");
while (cont<=5){
    
    printf("%d ",n);
    n=n+5;
    cont++;
}
    
    
    
return 0;
}