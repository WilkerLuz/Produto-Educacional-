#include<stdio.h>
int main(){
    int multiplus5=0;
    printf("Os cinco primeiros múltiplos de 5 são:\t");
   do{
       multiplus5+=5;
       printf("%d ",multiplus5);
    }
    while(multiplus5<25&&multiplus5%5==0);
    return 0;
}