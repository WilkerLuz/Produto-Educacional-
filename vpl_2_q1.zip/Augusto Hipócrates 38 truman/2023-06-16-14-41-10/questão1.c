#include <stdio.h>

void insertValues(int vetor[], int tamanho) {
    printf("Digite %d valores inteiros:\n", tamanho);
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &vetor[i]);
    }
}

int findSmallest(int vetor[], int tamanho) {
    int menor = vetor[0];
    for (int i = 1; i < tamanho; i++) {
        if (vetor[i] < menor) {
            menor = vetor[i];
        }
    }
    return menor;
}

int calculateSum(int vetor[], int tamanho) {
    int soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += vetor[i];
    }
    return soma;
}

void showMultiplesOfFive(int vetor[], int tamanho) {
    printf("Multiplos de 5 no vetor: ");
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] % 5 == 0) {
            printf("%d ", vetor[i]);
        }
    }
    printf("\n");
}

void sortDescending(int vetor[], int tamanho) {
    // Implementação do algoritmo de ordenação (ex: bubble sort)
    for (int i = 0; i < tamanho - 1; i++) {
        for (int j = 0; j < tamanho - i - 1; j++) {
            if (vetor[j] < vetor[j + 1]) {
                // Troca os elementos de posição
                int temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
            }
        }
    }
    printf("Vetor ordenado do maior para o menor: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

int main() {
    int vetor[8];
    int opcao;

    do {
        printf("\nMenu de Opções:\n");
        printf("1. Inserir valores inteiros no vetor\n");
        printf("2. Mostrar o menor valor do vetor\n");
        printf("3. Mostrar a soma dos valores do vetor\n");
        printf("4. Mostrar os múltiplos de 5 no vetor\n");
        printf("5. Ordenar o vetor do maior para o menor\n");
        printf("0. Sair do programa\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                insertValues(vetor, 8);
                break;
            case 2:
                if (vetor[0] != 0) {
                    int menor = findSmallest(vetor, 8);
                    printf("Menor valor do vetor: %d\n", menor);
                } else {
                    printf("O vetor está vazio. Insira valores primeiro.\n");
                }
                break;
            case 3:
                if (vetor[0] != 0) {
                    int soma = calculateSum(vetor, 8);
                    printf("Soma dos valores do vetor: %d\n", soma);
                } else {
                    printf("O vetor está vazio. Insira valores primeiro.\n");
                }
                break;
            case 4:
                if (vetor[0] != 0) {
                    show