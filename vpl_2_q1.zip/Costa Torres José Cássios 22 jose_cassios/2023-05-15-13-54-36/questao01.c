#include <stdio.h>

int main(void){
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    for (int i = 1; i <= 5; i ++){
        printf("%d ", i * 5);
    }
    
    return 0;
}