#include <stdio.h>

int main() {
    int a;
    printf("Os cinco primeiros múltiplos de 5 são: ");
    a = 5;
    do {
        printf("%d ", a);
        a = a+5;
    } while(a<26);
    return 0;
}