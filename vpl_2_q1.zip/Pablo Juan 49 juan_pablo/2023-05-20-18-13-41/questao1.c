#include <stdio.h>
int main () {
    
    int contador = 0, numero= 5;
    printf ("Os cinco primeiros múltiplos de 5 são: ");
    
    while (contador < 5) {
        printf("%d ", numero);
        numero += 5;
        contador++;
        
    }
    
    return 0;
}