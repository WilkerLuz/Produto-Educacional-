#include<stdio.h>
int main(){
    int i=5;
    int cont =1;
    printf("Os cinco primeiros múltiplos de 5 são:");
    while(cont<=5){
        printf(" %d",i);
          i= i+5;
          cont ++;
    }
}