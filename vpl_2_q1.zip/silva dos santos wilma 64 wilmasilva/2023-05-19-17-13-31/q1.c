#include <stdio.h>
int main (){
    int n=1,c=0;
    
    printf("Os cinco primeiros múltiplos de 5 são:\n");
    
    while(c<5){
        if(n%5==0){
        printf("%d\n",n);
        c++;
    }
     n++;
    }
    return 0;
    
}