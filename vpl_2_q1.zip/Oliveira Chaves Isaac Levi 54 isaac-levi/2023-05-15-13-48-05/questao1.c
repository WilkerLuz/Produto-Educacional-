#include<stdio.h>
int main(){
    int x;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    for(x = 5; x < 30; x = x + 5){
        printf("%d ",x);
    }
    
    return 0;
}