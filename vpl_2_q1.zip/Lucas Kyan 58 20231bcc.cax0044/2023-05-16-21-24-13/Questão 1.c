#include<stdio.h>

int main(){
    int multiplos[5];
    int num= 1;
    int contador= 0;

    while (contador<5){
        if(num%5==0){
            multiplos[contador] = num;
            contador++;
        }
        num++;
    }

    printf("Os cinco primeiros múltiplos de 5 são:\n");
    for (int i=0;i<5;i++){
        printf("%d\n",multiplos[i]);
    }
    printf("\n");
return 0;
}
