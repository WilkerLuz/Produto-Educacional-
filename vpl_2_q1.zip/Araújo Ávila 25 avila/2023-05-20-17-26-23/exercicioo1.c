#include<stdio.h>
int main()
{
    int i=0;
    printf("Os cinco primeiros múltiplos de 5 são: ");
    while( i <= 25){
        i++;
        if (i % 5 == 0){
            printf("%d ", i);
        }
    }
    
    return 0;
}