#include <stdio.h>

int main() {
    
    int multi=0,nums=0;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    while(nums<5) {
        multi++;
        if((multi%5)==0) {
            printf("%d ",multi);
            nums++;
        }
    }
    
    return 0;
}