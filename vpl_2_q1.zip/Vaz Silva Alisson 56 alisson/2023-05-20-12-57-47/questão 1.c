#include <stdio.h>
int main(){
    
    int v1 = 1, v2=5, v3;
    printf("Os cinco primeiros múltiplos de 5 são: ");
    while(v1<6)
    {
        v3=v1*v2;
        printf("%d ", v3);
        v1++;
    }
    
    
    
    
    return 0;
}