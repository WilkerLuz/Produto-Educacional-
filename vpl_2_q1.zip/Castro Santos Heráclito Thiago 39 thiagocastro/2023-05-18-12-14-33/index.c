#include <stdio.h>

int main(){
    printf(" Os cinco primeiros múltiplos de 5 são: ");
    for(int i = 1; i <= 25; i++){
        if(i % 5 == 0)printf("%d ", i);
    }
    return 0;
}