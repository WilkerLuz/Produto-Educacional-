#include<stdio.h>
int main()
{
    printf("Os cinco primeiros múltiplos de 5 são: ");
    for(int i = 5;i<26;i+=5){
        printf("%d ",i);
    }

    return 0;
}