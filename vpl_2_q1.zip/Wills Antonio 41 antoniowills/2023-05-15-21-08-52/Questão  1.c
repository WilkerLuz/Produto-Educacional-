#include <stdio.h>

int main(){
    int soma=0, mult;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    for(mult=1; mult<=5; mult++){
        soma+=5;
        printf("%d ", soma);
    }
}