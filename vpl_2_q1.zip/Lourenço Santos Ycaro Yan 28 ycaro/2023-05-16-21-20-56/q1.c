#include<stdio.h>
int main()
{
    int mult5=0, num1;
    
    mult5 = 0;
    num1 = 1;
    
    printf("Os cinco primeiros múltiplos de 5 são: \n");
    while(mult5 < 5){
        if(num1 % 5 == 0){
        printf("%d ", num1);
        mult5++;
        }
     num1++;
    }
    return 0;
}