#include <stdio.h>

int main (){
    
    int cont = 5;
    int num = 0;
    
    while(num <= 25 ){
      num++;
         
         if(num % cont == 0){
             
             printf("Os mutiplos de 5 são : %d\n ",num);
          
             
         }
    
    }
    

    
}