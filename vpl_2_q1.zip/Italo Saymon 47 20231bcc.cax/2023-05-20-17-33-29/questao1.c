#include <stdio.h>

int main(){
    
    int s = 5;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    while(s<=25) {
        printf("%d ", s);
        
       s+=5;
    }

    return 0;
    
}