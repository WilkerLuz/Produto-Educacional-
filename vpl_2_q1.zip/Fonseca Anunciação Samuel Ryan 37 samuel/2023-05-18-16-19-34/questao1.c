#include <stdio.h>
int main(){
    int num;
    printf("Os cinco primeiros múltiplos de 5 são:\t");
     for( num = 5; num <26; num+= 5){
     printf(" %d ", num);
     }
   
   
   return 0;
}