#include<stdio.h>

int main() {
    int c = 1;
    printf("Os cinco primeiros múltiplos de 5 são: ");
    while(c <= 5) {
        printf("%d ", 5 * c);
        ++c;
    }
    return 0;
}