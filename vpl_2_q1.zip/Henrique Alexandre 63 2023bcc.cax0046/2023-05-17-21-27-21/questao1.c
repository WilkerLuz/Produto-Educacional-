#include <stdio.h>
  int main() {
    int contador = 1;
    int multiplos = 0;

    printf("Os cinco primeiros múltiplos de 5 são: ");

    while (multiplos < 5) {
        int resultado = contador * 5;
        printf("%d ", resultado);
        contador++;
        multiplos++;
    }

    return 0;
  
}