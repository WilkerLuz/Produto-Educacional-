#include <stdio.h>

int main(){
    int cont = 0, num = 1;
    
    printf("Os cinco primeiros multiplos de 5 são:\n ");
    
    while(cont < 5) {
        if(num % 5 == 0){
            printf("%d\n", num);
            cont++;
        }
        num++;
    }
  
  return 0;
}