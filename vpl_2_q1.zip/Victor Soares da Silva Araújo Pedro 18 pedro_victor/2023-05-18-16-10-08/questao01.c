#include <stdio.h>

int main(){
    
    int num = 5, contador, res;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    for(contador = 1; contador < 6; contador++){
        res = num*contador;
        printf("%d ", res);
    }
    
    return 0;
}