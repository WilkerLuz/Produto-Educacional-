#include <stdio.h>
int main(){
    
    int i;
    
    // Esse printf está fora do loop para que seja exibido apenas uma vez, evitando várias linhas com a mesma frase
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    // O +=5 fará com que o valor incrementado seja de 5 em 5, necessário para os múltiplos de 5
    for (i=5; i<=25; i+=5)
    {
     // Esse printf está isolado para que exiba apenas os múltiplos de 5, ele é a continuação do primeiro printf, por isso não há quebra de linha lá 
        printf("%d ",i);
    }
    
    return 0;
}