#include <stdio.h>

int main() {
    
    int a = 5;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    while(a < 26){
        printf("%d ", a);
        a+=5;
    }
    
    return 0;
}