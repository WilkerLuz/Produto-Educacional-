#include <stdio.h>
int main(){
    
    int num = 5;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    while (num <= 25){
    
        printf("%d\t", num);
        num = num + 5;
    }
    
    return 0;    
}