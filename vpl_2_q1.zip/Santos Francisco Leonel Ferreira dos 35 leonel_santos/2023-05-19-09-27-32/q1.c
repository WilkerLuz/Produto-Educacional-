#include <stdio.h>

int main() {

    int num = 1;
    int i = 1;

    printf("Os cinco primeiros múltiplos de 5 são:");
    while (i <= 5){
        if(num % 5 == 0){
            printf("%d ", num);
            i++;
        }
        num++;
    }



    return 0;
}
