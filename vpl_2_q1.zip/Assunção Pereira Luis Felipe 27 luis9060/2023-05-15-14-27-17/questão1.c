#include <stdio.h>

int main(){
    int num1=5;
    int contador=0;
    
    printf("Os cinco primeiros múltiplos de 5 são: ");
    while(contador<5){
        printf("%d\t",num1);
    num1=num1+5;
    contador++;
    }
    
    
    
    return 0;
}