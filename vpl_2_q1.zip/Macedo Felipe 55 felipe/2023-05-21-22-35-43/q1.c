#include <stdio.h>
#include <math.h>
int main () {
    int n = 1;
    int c = 0;
    int m[5];
    
    while (c < 5){
        if ( n % 5 == 0){
            m[c]= n; 
            c++;
        
            
        }
        n++;
    }
    printf ("Os cinco primeiros numeros múltiplos de 5 são:");
     for (int i = 0; i < 5; i++) {
        printf(" %d", m[i]);
    }

    return 0;
    
}