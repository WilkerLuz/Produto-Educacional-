#include <stdio.h>
int main(){
  int multiplos5 = 0;
  printf("Os cinco primeiros múltiplos de 5 são: ");
  while(multiplos5 < 25){
      multiplos5 = multiplos5 + 5;
      printf("%d ",multiplos5);
  }
return 0;    
}