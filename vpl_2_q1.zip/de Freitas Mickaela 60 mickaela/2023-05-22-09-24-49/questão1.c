#include<stdio.h>

int main(){
    int multiplus5[5], contador = 1, num = 0;
    
        
        
    while (num < 5){ //numeros menores que 5//
        
        if(contador % 5 == 0){ //se o numero no contador for divisivel por 5 e seu resto for igual a 0, numero será incrementado na variavel multiplos//
        multiplus5[num] = contador;//num sendo adicionado na variavel multiplos//
        num++;
        
        
    }
        contador++;
    }
    printf("Os cinco primeiros múltiplos de 5 são: ");
    
    for(int i = 0; i < 5; i++){ //fazer contagem dos numeros maiores que 0 e menores que 5//
        
    printf("%d ", multiplus5[i]); // mostrando os multiplos de 5//
    
    }
    return 0;
    
}