#include<stdio.h>
int main(){
    int mult,cont;
    printf("Os cinco primeiros múltiplos de 5 são: ");
    for(cont=1; cont<=5; cont++)
    {
       mult=cont*5;
       printf("%i ",mult);
    }
    
}