#include <stdio.h>

int main(){

int num=0,i;  
printf("\nOs cinco primeiros múltiplos de 5 são: ");
for (i = 1;i<=5;i++)

 {

 num = num+5;

 printf("%d ",num);

 }

return 0;

}